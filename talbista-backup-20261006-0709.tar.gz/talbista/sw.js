// Talbista service worker: shows a visible notification for every push (payload-less); urgent is detected via the driver's own offers.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
const tok = () => new Promise(res => {
  try {
    const r = indexedDB.open('tb', 1); r.onupgradeneeded = () => r.result.createObjectStore('k');
    r.onsuccess = () => { const g = r.result.transaction('k').objectStore('k').get('tok'); g.onsuccess = () => res(g.result); g.onerror = () => res(null) };
    r.onerror = () => res(null);
  } catch (_) { res(null) }
});
self.addEventListener('push', e => e.waitUntil((async () => {
  let urgent = false; const t = await tok();
  if (t) { try { const o = await (await fetch('/api/driver/offers', { headers: { Authorization: 'Bearer ' + t } })).json(); urgent = Array.isArray(o) && o.some(x => x.urgent) } catch (_) {} }
  await self.registration.showNotification(urgent ? 'طلب مستعجل ⚡ - طلبيستا' : 'طلب جديد - طلبيستا', {
    body: 'افتح التطبيق لقبول الطلب', tag: 'offer', renotify: true, requireInteraction: true,
    vibrate: urgent ? [500, 150, 500, 150, 500, 150, 900] : [250, 120, 250], data: { url: '/driver' } });
})()));
self.addEventListener('notificationclick', e => { e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window' }).then(l => { for (const c of l) if (c.url.includes('/driver')) return c.focus(); return self.clients.openWindow('/driver') })) });
