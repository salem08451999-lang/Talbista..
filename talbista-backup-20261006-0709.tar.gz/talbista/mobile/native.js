// Native shell glue (Capacitor): FCM registration, notification tap -> open order, account-type switch link.
(function () {
  const C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  window.tbNative = {};
  const PN = C.Plugins && C.Plugins.PushNotifications, base = window.TB_API || '';
  const authTok = () => localStorage.getItem('dr') || localStorage.getItem('t');
  const post = (p, b, t) => fetch(base + '/api' + p, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t }, body: JSON.stringify(b) });
  async function sync() {
    const f = localStorage.getItem('fcm'), t = authTok(); if (!f || !t) return;
    const k = f + '|' + t; if (localStorage.getItem('fcm_sent') === k) return;
    try { const r = await post('/devices/register', { token: f }, t); if (r.ok) localStorage.setItem('fcm_sent', k); } catch (_) {}
  }
  window.tbNative.unregister = async t => {
    const f = localStorage.getItem('fcm'); localStorage.removeItem('fcm_sent');
    if (f && t) { try { await post('/devices/unregister', { token: f }, t); } catch (_) {} }
  };
  if (PN) {
    PN.addListener('registration', x => { localStorage.setItem('fcm', x.value); sync(); });
    PN.addListener('registrationError', e => console.log('push registration error', JSON.stringify(e)));
    PN.addListener('pushNotificationReceived', () => { if (window.load && localStorage.getItem('dr')) window.load(); });
    PN.addListener('pushNotificationActionPerformed', a => {
      const d = (a.notification && a.notification.data) || {};
      if (d.order_id) localStorage.setItem('open_order', d.order_id);
      const dest = localStorage.getItem('dr') ? 'driver.html' : 'customer.html';
      if (!location.pathname.endsWith(dest)) location.replace(dest);
      else if (d.kind !== 'offer' && window.detail && d.order_id) window.detail(d.order_id);
    });
    const init = async () => {
      if (!authTok()) return;
      try {
        let p = await PN.checkPermissions();
        if (p.receive !== 'granted') p = await PN.requestPermissions();
        if (p.receive === 'granted') await PN.register();
      } catch (e) { console.log(e); }
    };
    setInterval(() => { sync(); if (authTok() && !localStorage.getItem('fcm')) init(); }, 4000);
    document.addEventListener('DOMContentLoaded', init);
  }
  document.addEventListener('DOMContentLoaded', () => {
    const a = document.createElement('a'); a.href = 'app.html?choose=1'; a.textContent = 'تغيير نوع الحساب';
    a.style.cssText = 'position:fixed;bottom:6px;inset-inline-start:10px;font-size:12px;opacity:.6;z-index:5'; document.body.appendChild(a);
  });
})();
