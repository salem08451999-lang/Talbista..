# طلبيستا - تطبيق Android (Capacitor)
يغلّف نفس واجهات العميل والسائق (مضمّنة داخل التطبيق) ويتصل بالـBackend عبر HTTPS. مجلد `android/` يُولَّد بـ`npx cap add android` ثم تُطبَّق عليه تخصيصاتنا (`apply_android_overlay.py`): قنوات الإشعارات بنغمة واهتزاز مختلفين للعادي والمستعجل، النغمات، صلاحيات الإشعار.

## البناء عبر GitHub Actions
1. ارفع مجلد المشروع كاملاً (الجذر هو `talbista/`) إلى مستودع GitHub.
2. Settings > Secrets and variables > Actions: أضف Secret باسم `GOOGLE_SERVICES_JSON` (محتوى ملف Firebase `google-services.json` لتطبيق Android بحزمة `ly.talbista.app`)، وVariable باسم `SERVER_URL` (رابط الـBackend بـHTTPS).
3. Actions > Build Android APK > Run workflow. نزّل `talbista-debug-apk` ثم ثبّته على الهاتف (اسمح بالتثبيت من مصدر غير معروف). الـArtifact الآخر هو مصدر Android Studio.

## إعداد الـBackend للإشعارات
- Firebase Console > Project settings > Service accounts > Generate new private key.
- على الخادم: `FCM_SERVICE_ACCOUNT_JSON` = محتوى ملف المفتاح (أو مساره)، و`pip install -r requirements.txt`.
- `CORS_ORIGINS` افتراضيها `https://localhost,capacitor://localhost,http://localhost` (تكفي للتطبيق).

## ملاحظات
- التوكن الصالح لسبعة أيام؛ بعدها يطلب التطبيق تسجيل الدخول.
- للتجربة على شبكة محلية بلا HTTPS: `ALLOW_CLEARTEXT=1` مع `SERVER_URL=http://...` (للتجربة فقط).
- نسخة iPhone: `npx cap add ios` على جهاز Mac مع حساب Apple Developer وإعداد APNs في Firebase (غير مُجهَّز بعد).

## نسخة تجريبية بلا خادم (DEMO)
- معاينة فورية على الهاتف: افتح ملف `demo/talbista-demo.html` (صفحة واحدة بكل الشاشات وبيانات وهمية).
- APK تجريبي: GitHub > Actions > "Build Android DEMO APK" > Run workflow (بلا أي أسرار أو Firebase أو خادم). نزّل `talbista-demo-apk`.
- كل APK يُبنى على GitHub يُوقَّع بمفتاح تجريبي جديد؛ احذف النسخة القديمة من الهاتف قبل تثبيت الجديدة.
- الدخول في العرض: الأرقام التي تبدأ بـ092 سائق، و0910000000 مدير، وغيرها عميل، وأي كلمة مرور.
