// Talbista DEMO: in-browser fake backend (no server). All data is fictional. Overrides fetch() for /api/* calls.
(function (g) {
  const K = 'tb_demo_v1', MEM = {}, now = () => Math.floor(Date.now() / 1000);
  const st = () => { try { return localStorage.getItem(K) } catch (e) { return MEM[K] } }, sv = v => { try { localStorage.setItem(K, v) } catch (e) { MEM[K] = v } };
  const av = c => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" fill="${c}"/><circle cx="48" cy="36" r="18" fill="#fff"/><path d="M14 96c4-26 20-34 34-34s30 8 34 34z" fill="#fff"/></svg>`);
  const FLOW = ['SEARCHING_DRIVER', 'DRIVER_ASSIGNED', 'DRIVER_ON_THE_WAY', 'DRIVER_ARRIVED', 'ORDER_PICKED_UP', 'ON_THE_WAY_TO_CUSTOMER', 'DELIVERED'], STEP = [0, 5, 11, 17, 23, 29, 35];
  const SV = ['شراء من مطعم', 'شراء من محل', 'استلام أمانة/طرد', 'توصيل مستندات', 'مشوار خاص', 'مهمة أخرى'];
  const OFFERS = [{ urgent: 0, distance_m: 420, pickup: 'مطعم السرايا - طرابلس', dropoff: 'حي الأندلس، شارع 5', details: 'وجبتان وعصير' }, { urgent: 1, distance_m: 1700, kind: 'STORE', store_name: 'صيدلية النور', store_address: 'زاوية الدهماني، طرابلس', delivery_fee: 30, is_paid: 0, order_value: 45, notes: 'اتصل قبل الوصول', pickup: 'صيدلية النور - زاوية الدهماني', dropoff: 'سوق الجمعة، عمارة 12', details: 'دواء عاجل' }, { urgent: 0, distance_m: 3000, pickup: 'مكتبة المدينة', dropoff: 'جامعة طرابلس', details: 'تسليم مستندات' }];
  const seed = () => { const t = now(), h = 3600; return {
    nid: 100, lid: 10, vid: 3, hid: 2, aid: 5, cust: { id: 201, name: 'عميل تجريبي', phone: '0931234567' },
    services: SV.map((n, i) => ({ id: i + 1, name: n, active: 1 })),
    drivers: [
      { id: 101, name: 'أحمد المبروك', phone: '0912345678', active: 1, photo: av('#0b7a55'), car: 'Kia', model: 'Rio', year: 2021, color: 'أبيض', plate: 'ط 4821', available: 1, outstanding: 42, rating_sum: 46, rating_n: 10, blocked_until: 0 },
      { id: 102, name: 'سالم بن علي', phone: '0923456789', active: 1, photo: av('#1d5fa8'), car: 'Hyundai', model: 'Accent', year: 2019, color: 'رمادي', plate: 'ط 1177', available: 1, outstanding: 96, rating_sum: 28, rating_n: 6, blocked_until: 0 },
      { id: 103, name: 'يوسف الترهوني', phone: '0914567890', active: 1, photo: av('#a85d1d'), car: 'Toyota', model: 'Yaris', year: 2020, color: 'أسود', plate: 'ط 9034', available: 0, outstanding: 15, rating_sum: 18, rating_n: 4, blocked_until: t + 10 * h }],
    customers: [{ id: 201, name: 'عميل تجريبي', phone: '0931234567', active: 1 }, { id: 202, name: 'مريم الفيتوري', phone: '0945678901', active: 1 }],
    orders: [
      { id: 90, cust: 201, service_id: 1, pickup: 'مطعم الباشا', dropoff: 'حي الأندلس', details: 'وجبة غداء', urgent: 0, status: 'DELIVERED', driver_id: 101, agreed_price: 15, created: t - 86400 * 2, confirmed: 1, owner: 's' },
      { id: 91, cust: 201, service_id: 3, pickup: 'مكتب الشحن', dropoff: 'عين زارة', details: 'استلام طرد', urgent: 1, status: 'DELIVERED', driver_id: 102, agreed_price: 30, created: t - 86400, confirmed: 1, owner: 's' },
      { id: 92, cust: 201, service_id: 2, pickup: 'سوبرماركت الهاني', dropoff: 'قرجي', details: 'أغراض منزلية', urgent: 0, status: 'CANCELLED', driver_id: null, agreed_price: null, created: t - 3600 * 5, confirmed: 0, owner: 's' }],
    ledger: [
      { id: 1, at: t - 86400 * 2, driver_id: 101, order_id: 90, kind: 'COMMISSION', urgent: 0, base: 15, pct: 20, amount: 3, balance_after: 39, admin_id: null, note: null },
      { id: 2, at: t - 86400, driver_id: 102, order_id: 91, kind: 'COMMISSION', urgent: 1, base: 30, pct: 20, amount: 6, balance_after: 96, admin_id: null, note: null }],
    handovers: [{ id: 1, driver_id: 102, status: 'REQUESTED', requested: t - 1800, amount: null, confirmed_at: null, admin_id: null }],
    violations: [{ id: 1, driver_id: 103, order_id: null, reason: 'تجاهل طلب بعد قبوله', fine: 10, created: t - 2 * h, blocked_until: t + 10 * h, status: 'ACTIVE', admin_id: 1, cancel_note: null }, { id: 2, driver_id: 101, order_id: 90, reason: 'تأخر كبير (أُلغيت بعد المراجعة)', fine: 10, created: t - 86400 * 4, blocked_until: t - 86400 * 3, status: 'CANCELLED', admin_id: 1, cancel_note: 'اعتذر العميل' }],
    audit: [{ id: 1, at: t - 7200, actor: 1, action: 'create_violation', detail: '{"driver":103}' }, { id: 2, at: t - 86400, actor: 1, action: 'settings', detail: '{"commission":20}' }],
    settings: { commission: 20, normal_base: 15, urgent_base: 30, driver_limit: 100, offer_timeout: 60, auto_dispatch: 1, violation_fine: 10, violation_block_hours: 24 },
    notes: { 201: [{ id: 1, text: 'مرحبًا بك في طلبيستا - نسخة تجريبية', at: t - 600, read: 0 }], 101: [{ id: 1, text: 'طلب جديد #5001', at: t - 300, read: 0 }] },
    dr: { available: 1, offer: Object.assign({ order_id: 5001 }, OFFERS[0]), n: 0 } }; };
  let D; const load = () => { if (D) return D; try { D = JSON.parse(st()) } catch (e) {} D = D || seed(); D.store = D.store || { name: 'متجر الأمل', phone: '0951234567', manager_name: 'خالد الزروق', address: 'شارع الجمهورية، طرابلس', activity_type: 'مطعم' }; return D }, save = () => sv(JSON.stringify(D));
  const drv = id => D.drivers.find(d => d.id == id), ord = id => D.orders.find(o => o.id == id), note = (u, text) => (D.notes[u] = D.notes[u] || []).unshift({ id: D.lid++, text, at: now(), read: 0 });
  const rating = d => d.rating_n ? Math.round(d.rating_sum / d.rating_n * 100) / 100 : null;
  const cstat = o => { if (o.owner !== 'c' || o.cancelled) return o.cancelled ? 'CANCELLED' : o.status; const e = now() - o.created; let i = 0; STEP.forEach((s, k) => { if (e >= s) i = k }); return FLOW[i] };
  const view = o => { const s = cstat(o), i = FLOW.indexOf(s), r = Object.assign({}, o, { status: s, driver_id: o.owner === 'c' ? (i >= 1 ? 101 : null) : o.driver_id }); r.history = [{ status: 'NEW', at: o.created }].concat(o.owner === 'c' ? FLOW.slice(0, i + 1).map((x, k) => ({ status: x, at: o.created + STEP[k] })) : [{ status: s, at: o.created }]); if (o.cancelled) r.history.push({ status: 'CANCELLED', at: now() }); const d = r.driver_id && drv(r.driver_id); r.driver = d ? { name: d.name, phone: d.phone, photo: d.photo, car: d.car, model: d.model, year: d.year, color: d.color, plate: d.plate, rating: rating(d) } : null; if (o.rated) r.confirmed = 1; return r };
  const nextOffer = () => { D.dr.n++; D.dr.offer = Object.assign({ order_id: 5001 + D.dr.n }, OFFERS[D.dr.n % 3]); };
  const stats = () => { const os = D.orders.map(view), open = x => !['DELIVERED', 'CANCELLED'].includes(x.status), t = now(); return { customers: D.customers.length, drivers: D.drivers.length, available: D.drivers.filter(d => d.available).length, active_orders: os.filter(open).length, urgent: os.filter(o => o.urgent).length, normal: os.filter(o => !o.urgent).length, delivered: os.filter(o => o.status === 'DELIVERED').length, cancelled: os.filter(o => o.status === 'CANCELLED').length, commissions_total: D.ledger.filter(l => l.kind === 'COMMISSION').reduce((a, l) => a + l.amount, 0), outstanding_total: D.drivers.reduce((a, d) => a + d.outstanding, 0), at_limit: D.drivers.filter(d => d.outstanding >= D.settings.driver_limit).length, blocked_drivers: D.drivers.filter(d => d.blocked_until > t).length, fines_total: D.violations.filter(v => v.status === 'ACTIVE').reduce((a, v) => a + v.fine, 0), handover_requests: D.handovers.filter(h => h.status === 'REQUESTED').length } };
  const ok = [200, { ok: 1 }];
  function route(m, p, b, tok) {
    load(); const role = tok === 'demo-admin' ? 'ADMIN' : tok === 'demo-driver' ? 'DRIVER' : tok === 'demo-customer' ? 'CUSTOMER' : tok === 'demo-store' ? 'STORE' : null, d1 = drv(101); let x;
    if (m === 'POST' && p === '/login') { const ph = String(b.phone || ''); const r = ph === '0910000000' ? 'ADMIN' : ph.startsWith('092') ? 'DRIVER' : (ph === D.store.phone || ph.startsWith('095')) ? 'STORE' : 'CUSTOMER'; return [200, { token: 'demo-' + r.toLowerCase(), role: r, name: r === 'ADMIN' ? 'المدير' : r === 'DRIVER' ? d1.name : r === 'STORE' ? D.store.name : D.cust.name }]; }
    if (m === 'POST' && p === '/register') return [200, { id: 201 }];
    if (m === 'POST' && p === '/register/store') { D.store = { name: b.store_name, phone: b.phone, manager_name: b.manager_name, address: b.address, activity_type: b.activity_type }; return [200, { id: 301 }]; }
    if (!role) return [401, { error: 'forbidden' }];
    if (p === '/me') return m === 'PATCH' ? (b.name && (D.cust.name = b.name), ok) : [200, role === 'DRIVER' ? { id: 101, role, name: d1.name, phone: d1.phone, driver: { available: d1.available, outstanding: d1.outstanding, blocked_until: d1.blocked_until, status: d1.available ? 'AVAILABLE' : 'UNAVAILABLE' } } : role === 'ADMIN' ? { id: 1, role, name: 'المدير', phone: '0910000000' } : role === 'STORE' ? { id: 301, role, name: D.store.name, phone: D.store.phone, store: { manager_name: D.store.manager_name, address: D.store.address, activity_type: D.store.activity_type } } : Object.assign({ role }, D.cust)];
    if (p === '/logout') return ok;
    if (p === '/services') return [200, D.services.filter(s => s.active)];
    if (p === '/notifications') return [200, D.notes[role === 'DRIVER' ? 101 : role === 'STORE' ? 301 : 201] || []];
    if (p === '/notifications/read') { (D.notes[role === 'DRIVER' ? 101 : role === 'STORE' ? 301 : 201] || []).forEach(n => n.read = 1); return ok; }
    if (role === 'STORE') {
      const own = D.orders.filter(o => o.cust === 301), nf = [404, { error: 'not found' }];
      if (p === '/store/config') return [200, { fee_normal: 15, fee_urgent: 30, lat: D.store.lat ?? null, lng: D.store.lng ?? null }];
      if (p === '/store/location') { D.store.lat = b.lat; D.store.lng = b.lng; return ok; }
      if (p === '/store/orders' && m === 'GET') return [200, own.map(view).sort((a, c) => c.id - a.id)];
      if (p === '/store/orders' && m === 'POST') { const o = { id: D.nid++, cust: 301, kind: 'STORE', service_id: null, pickup: b.pickup || D.store.address, dropoff: b.dropoff, details: b.details, contact: b.contact, notes: b.notes, order_value: b.is_paid ? 0 : +b.order_value, is_paid: b.is_paid ? 1 : 0, delivery_fee: b.urgent ? 30 : 15, urgent: b.urgent ? 1 : 0, status: 'SEARCHING_DRIVER', driver_id: null, agreed_price: null, created: now(), confirmed: 0, owner: 'c' }; D.orders.push(o); note(301, `تم إنشاء الطلب #${o.id}`); return [200, { id: o.id, delivery_fee: o.delivery_fee }]; }
      if ((x = p.match(/^\/store\/orders\/(\d+)\/cancel$/))) { const o = ord(x[1]); if (!o || o.cust !== 301) return nf; if (['ORDER_PICKED_UP', 'ON_THE_WAY_TO_CUSTOMER', 'DELIVERED', 'CANCELLED'].includes(cstat(o))) return [409, { error: 'cannot cancel now' }]; o.cancelled = 1; o.status = 'CANCELLED'; return ok; }
      if ((x = p.match(/^\/orders\/(\d+)$/))) { const o = ord(x[1]); return o && o.cust === 301 ? [200, view(o)] : nf; }
    }
    if (p === '/support') return [200, { phone: '+218910000000', whatsapp: '218910000000' }];
    if (p === '/support/report') return ok;
    if (role === 'CUSTOMER') {
      if (p === '/orders' && m === 'GET') return [200, D.orders.filter(o => o.cust === 201 && o.owner !== 'd').map(view).sort((a, c) => c.id - a.id)];
      if (p === '/orders' && m === 'POST') { const o = { id: D.nid++, cust: 201, service_id: b.service_id, pickup: b.pickup, dropoff: b.dropoff, details: b.details, urgent: b.urgent ? 1 : 0, status: 'SEARCHING_DRIVER', driver_id: null, agreed_price: null, created: now(), confirmed: 0, owner: 'c' }; D.orders.push(o); note(201, `تم إنشاء الطلب #${o.id}`); return [200, { id: o.id, note: 'سعر تنفيذ المهمة يتم الاتفاق عليه بين العميل والسائق قبل التأكيد' }]; }
      if ((x = p.match(/^\/orders\/(\d+)(?:\/(cancel|confirm|rate))?$/))) { const o = ord(x[1]); if (!o || o.cust !== 201) return [404, { error: 'not found' }];
        if (!x[2]) return [200, view(o)];
        if (x[2] === 'cancel') { if (['ORDER_PICKED_UP', 'ON_THE_WAY_TO_CUSTOMER', 'DELIVERED', 'CANCELLED'].includes(cstat(o))) return [409, { error: 'cannot cancel now' }]; o.cancelled = 1; o.status = 'CANCELLED'; return ok; }
        if (x[2] === 'confirm') return cstat(o) === 'DELIVERED' ? (o.confirmed = 1, ok) : [409, { error: 'not delivered' }];
        if (o.rated) return [409, { error: 'already rated' }]; o.rated = 1; const d = drv(101); d.rating_sum += b.stars; d.rating_n++; return ok; }
    }
    if (role === 'DRIVER') {
      if (p === '/driver/available') { d1.available = b.available ? 1 : 0; return ok; }
      if (p === '/driver/offers') return [200, d1.available && d1.outstanding < D.settings.driver_limit && d1.blocked_until < now() && D.dr.offer && !D.orders.some(o => o.owner === 'd' && !['DELIVERED', 'CANCELLED'].includes(o.status)) ? [Object.assign({}, D.dr.offer, { expires: now() + 45 })] : []];
      if ((x = p.match(/^\/driver\/offers\/(\d+)\/(accept|reject)$/))) { const f = D.dr.offer; if (!f) return [409, { error: 'offer not available' }];
        if (x[2] === 'accept') D.orders.push({ id: f.order_id, cust: 202, service_id: 1, pickup: f.pickup, dropoff: f.dropoff, details: f.details, urgent: f.urgent, status: 'DRIVER_ASSIGNED', driver_id: 101, agreed_price: b.agreed_price ?? null, created: now(), confirmed: 0, owner: 'd', kind: f.kind || 'CUSTOMER', delivery_fee: f.delivery_fee, is_paid: f.is_paid, order_value: f.order_value, notes: f.notes, contact: f.kind === 'STORE' ? 'سالم - 0945678901' : null, pickup_lat: 32.8872, pickup_lng: 13.1913, dropoff_lat: 32.8950, dropoff_lng: 13.2100 }); nextOffer(); if (x[2] === 'accept') D.dr.offer = null; return ok; }
      if (p === '/driver/orders') return [200, D.orders.filter(o => o.driver_id === 101 && o.owner !== 'c').sort((a, c) => c.id - a.id).map(o => { const open = !['DELIVERED', 'CANCELLED'].includes(o.status); return Object.assign({}, o, { store_address: open && o.kind === 'STORE' ? 'زاوية الدهماني، طرابلس' : null, customer_name: open ? (o.kind === 'STORE' ? 'صيدلية النور' : o.cust === 202 ? 'مريم الفيتوري' : D.cust.name) : null, customer_phone: open ? (o.cust === 202 ? '0945678901' : D.cust.phone) : null }); })];
      if ((x = p.match(/^\/driver\/orders\/(\d+)\/(status|cancel)$/))) { const o = ord(x[1]); if (!o) return [404, { error: 'not found' }];
        if (x[2] === 'cancel') { if (FLOW.indexOf(o.status) >= 4) return [409, { error: 'cannot cancel now' }]; o.status = 'CANCELLED'; o.driver_id = null; if (!D.dr.offer) nextOffer(); return ok; }
        const i = FLOW.indexOf(o.status); if (b.status !== FLOW[i + 1] || i < 1) return [409, { error: 'invalid transition' }]; o.status = b.status;
        if (b.status === 'DELIVERED') { const base = o.urgent ? 30 : 15, am = base * D.settings.commission / 100; d1.outstanding += am; D.ledger.unshift({ id: D.lid++, at: now(), driver_id: 101, order_id: o.id, kind: 'COMMISSION', urgent: o.urgent, base, pct: D.settings.commission, amount: am, balance_after: d1.outstanding, admin_id: null, note: null }); if (d1.outstanding >= D.settings.driver_limit) note(101, 'وصلت عهدتك إلى الحد المسموح. يرجى تسوية العهدة لدى الشركة قبل استقبال طلبات جديدة.'); if (!D.dr.offer) nextOffer(); }
        return ok; }
      if (p === '/driver/handover-request') { if (D.handovers.some(h => h.driver_id === 101 && h.status === 'REQUESTED')) return [409, { error: 'already requested' }]; D.handovers.unshift({ id: D.hid++, driver_id: 101, status: 'REQUESTED', requested: now(), amount: null, confirmed_at: null, admin_id: null }); return ok; }
      if (p === '/driver/ledger') return [200, D.ledger.filter(l => l.driver_id === 101).sort((a, c) => c.id - a.id)];
      if (p === '/driver/violations') return [200, D.violations.filter(v => v.driver_id === 101).map(v => ({ id: v.id, order_id: v.order_id, reason: v.reason, fine: v.fine, created: v.created, blocked_until: v.blocked_until, status: v.status }))];
    }
    if (role === 'ADMIN' && p.startsWith('/admin/')) { const a = p.slice(6);
      if (a === '/stats') return [200, stats()];
      if (a === '/drivers') return m === 'POST' ? (D.drivers.push({ id: D.nid++, name: b.name, phone: b.phone, active: 1, photo: av('#555'), car: b.car, model: b.model, year: b.year, color: b.color, plate: b.plate, available: 0, outstanding: 0, rating_sum: 0, rating_n: 0, blocked_until: 0 }), [200, { id: D.nid - 1 }]) : [200, D.drivers];
      if ((x = a.match(/^\/drivers\/(\d+)(?:\/(password|photo|violations))?$/))) { const d = drv(x[1]); if (!d) return [404, { error: 'not found' }];
        if (!x[2]) { Object.keys(b).forEach(k => d[k] = k === 'active' ? (b[k] ? 1 : 0) : b[k]); return ok; }
        if (x[2] === 'photo') { d.photo = b.image; return ok; } if (x[2] === 'password') return ok;
        const fine = D.settings.violation_fine, u = now() + D.settings.violation_block_hours * 3600; d.blocked_until = Math.max(d.blocked_until, u); d.outstanding += fine; D.violations.unshift({ id: D.vid++, driver_id: d.id, order_id: b.order_id || null, reason: b.reason, fine, created: now(), blocked_until: u, status: 'ACTIVE', admin_id: 1, cancel_note: null }); D.ledger.unshift({ id: D.lid++, at: now(), driver_id: d.id, order_id: b.order_id || null, kind: 'FINE', urgent: null, base: null, pct: null, amount: fine, balance_after: d.outstanding, admin_id: 1, note: b.reason }); return [200, { id: D.vid - 1 }]; }
      if (a === '/orders') return [200, D.orders.map(view).sort((p_, q) => q.id - p_.id)];
      if ((x = a.match(/^\/orders\/(\d+)\/(assign|cancel)$/))) { const o = ord(x[1]); if (!o) return [404, { error: 'not found' }]; if (x[2] === 'cancel') { o.cancelled = 1; o.status = 'CANCELLED'; } else { o.owner = o.owner === 'c' ? 's' : o.owner; o.driver_id = b.driver_id; o.status = 'DRIVER_ASSIGNED'; } return ok; }
      if (a === '/services') return m === 'POST' ? (D.services.push({ id: D.services.length + 1, name: b.name, active: 1 }), [200, { id: D.services.length }]) : [200, D.services];
      if ((x = a.match(/^\/services\/(\d+)$/))) { const s = D.services.find(s_ => s_.id == x[1]); Object.keys(b).forEach(k => s[k] = k === 'active' ? (b[k] ? 1 : 0) : b[k]); return ok; }
      if (a === '/settings') return m === 'PUT' ? (Object.assign(D.settings, b), ok) : [200, D.settings];
      if (a === '/handovers') return [200, D.handovers];
      if ((x = a.match(/^\/handovers\/(\d+)\/confirm$/))) { const h = D.handovers.find(h_ => h_.id == x[1] && h_.status === 'REQUESTED'), d = h && drv(h.driver_id); if (!h) return [404, { error: 'no pending request' }]; h.status = 'CONFIRMED'; h.amount = d.outstanding; h.confirmed_at = now(); h.admin_id = 1; D.ledger.unshift({ id: D.lid++, at: now(), driver_id: d.id, order_id: null, kind: 'HANDOVER', urgent: null, base: null, pct: null, amount: -d.outstanding, balance_after: 0, admin_id: 1, note: null }); d.outstanding = 0; if (d.id === 101) note(101, 'تم تأكيد استلام العهدة'); return [200, { ok: 1, amount: h.amount }]; }
      if (a === '/ledger') return [200, D.ledger.slice().sort((p_, q) => q.id - p_.id)];
      if (a === '/customers') return [200, D.customers];
      if ((x = a.match(/^\/customers\/(\d+)$/))) { const c = D.customers.find(c_ => c_.id == x[1]); c.active = b.active ? 1 : 0; return ok; }
      if (a === '/audit') return [200, D.audit];
      if (a === '/violations') return [200, D.violations.map(v => Object.assign({ driver_name: drv(v.driver_id).name }, v))];
      if ((x = a.match(/^\/violations\/(\d+)\/cancel$/))) { const v = D.violations.find(v_ => v_.id == x[1] && v_.status === 'ACTIVE'); if (!v) return [409, { error: 'not active' }]; v.status = 'CANCELLED'; v.cancel_note = b.note; const d = drv(v.driver_id); d.outstanding -= v.fine; d.blocked_until = 0; return ok; }
    }
    return m === 'GET' ? [200, []] : ok;
  }
  g.__tbDemo = 1; g.TBMock = { async fetch(url, o) { o = o || {}; const p = new URL(url, 'http://x').pathname.replace(/^.*?\/api\//, '/'); await new Promise(r => setTimeout(r, 120)); const [s, j] = route(o.method || 'GET', p, o.body ? JSON.parse(o.body) : {}, ((o.headers || {}).Authorization || '').slice(7)); save(); return new Response(JSON.stringify(j), { status: s, headers: { 'Content-Type': 'application/json' } }); },
    reset() { D = null; sv(''); try { ['t', 'dr', 'at', 'dr_S'].forEach(k => localStorage.removeItem(k)) } catch (e) {} }, route };
  const real = g.fetch && g.fetch.bind(g);
  if (!g.__tbShared) g.fetch = (u, o) => String(u).includes('/api/') ? TBMock.fetch(u, o) : real(u, o);
  if (g.document && g.parent === g && !g.__tbShared) g.document.addEventListener('DOMContentLoaded', () => { const a = g.document.createElement('a'); a.href = 'app.html?choose=1'; a.textContent = '◂ قائمة العرض التجريبي'; a.style.cssText = 'position:fixed;bottom:76px;inset-inline-end:8px;font-size:12px;background:#0b7a55;color:#fff;padding:3px 10px;border-radius:99px;z-index:50;text-decoration:none'; g.document.body.appendChild(a); });
})(typeof window !== 'undefined' ? window : globalThis);
