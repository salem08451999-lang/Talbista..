// Talbista map helpers (no external library): OpenStreetMap raster tiles, drag / zoom buttons / tap-to-pin, emoji markers, GPS helper.
// Tiles: window.TB_TILES can override the template (e.g. a paid tile provider). The public OSM server is for light use only.
(function (g) {
  const TILES = () => g.TB_TILES || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', DEF = [32.8872, 13.1913]; // Tripoli
  const px = (la, ln, z) => { const s = 256 * 2 ** z, r = la * Math.PI / 180; return [(ln + 180) / 360 * s, (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * s]; };
  const ll = (x, y, z) => { const s = 256 * 2 ** z, n = Math.PI - 2 * Math.PI * y / s; return [180 / Math.PI * Math.atan(Math.sinh(n)), x / s * 360 - 180]; };
  function make(el, o) {
    o = o || {}; el.style.cssText += ';position:relative;overflow:hidden;touch-action:none;background:#dfe6e2;border-radius:12px;direction:ltr;min-height:180px';
    const tl = document.createElement('div'), mk = document.createElement('div'), zb = document.createElement('div');
    [tl, mk].forEach(d => { d.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%'; el.appendChild(d); }); mk.style.pointerEvents = 'none';
    zb.style.cssText = 'position:absolute;right:6px;top:6px;display:flex;flex-direction:column;gap:4px;z-index:3';
    zb.innerHTML = '<button type="button" data-z="1" aria-label="تكبير">+</button><button type="button" data-z="-1" aria-label="تصغير">−</button>';
    zb.querySelectorAll('button').forEach(b => b.style.cssText = 'width:36px;height:36px;border-radius:8px;border:1px solid #0003;background:#fffe;color:#14201c;font:700 20px sans-serif;padding:0'); el.appendChild(zb);
    const at = document.createElement('div'); at.textContent = '© OpenStreetMap'; at.style.cssText = 'position:absolute;bottom:2px;left:4px;font:10px sans-serif;background:#fffc;color:#333;padding:0 4px;pointer-events:none;z-index:3'; el.appendChild(at);
    let c = o.center || DEF, z = o.zoom || 15, pts = [];
    function draw() {
      const w = el.clientWidth || 300, h = el.clientHeight || 220, [cx, cy] = px(c[0], c[1], z), x0 = cx - w / 2, y0 = cy - h / 2, n = 2 ** z; tl.innerHTML = '';
      for (let tx = Math.floor(x0 / 256); tx <= Math.floor((x0 + w) / 256); tx++) for (let ty = Math.floor(y0 / 256); ty <= Math.floor((y0 + h) / 256); ty++) {
        if (ty < 0 || ty >= n) continue; const im = new Image(); im.draggable = false; im.alt = '';
        im.style.cssText = `position:absolute;left:${tx * 256 - x0}px;top:${ty * 256 - y0}px;width:256px;height:256px`; im.onerror = () => { im.style.visibility = 'hidden'; }; im.src = TILES().replace('{z}', z).replace('{x}', ((tx % n) + n) % n).replace('{y}', ty); tl.appendChild(im);
      }
      mk.innerHTML = ''; pts.forEach(p => { const [x, y] = px(p.lat, p.lng, z), d = document.createElement('div'); d.textContent = p.icon || '📍'; d.title = p.label || '';
        d.style.cssText = `position:absolute;left:${x - x0}px;top:${y - y0}px;transform:translate(-50%,-100%);font-size:28px;line-height:1;filter:drop-shadow(0 1px 2px #0006)`; mk.appendChild(d); });
    }
    let dn = null;
    el.addEventListener('pointerdown', e => { if (e.target.closest('[data-z]')) return; dn = { x: e.clientX, y: e.clientY, c: px(c[0], c[1], z), m: 0 }; try { el.setPointerCapture(e.pointerId); } catch (_) {} });
    el.addEventListener('pointermove', e => { if (!dn) return; const dx = e.clientX - dn.x, dy = e.clientY - dn.y; dn.m = Math.max(dn.m, Math.abs(dx) + Math.abs(dy)); if (dn.m > 6) { c = ll(dn.c[0] - dx, dn.c[1] - dy, z); draw(); } });
    el.addEventListener('pointerup', e => { if (dn && dn.m <= 6 && o.onPick) { const r = el.getBoundingClientRect(), [cx, cy] = px(c[0], c[1], z), p = ll(cx - r.width / 2 + (e.clientX - r.left), cy - r.height / 2 + (e.clientY - r.top), z); o.onPick(p[0], p[1]); } dn = null; });
    el.addEventListener('wheel', e => { e.preventDefault(); z = Math.max(3, Math.min(19, z + (e.deltaY < 0 ? 1 : -1))); draw(); }, { passive: false });
    zb.addEventListener('click', e => { const b = e.target.closest('[data-z]'); if (b) { z = Math.max(3, Math.min(19, z + +b.dataset.z)); draw(); } });
    if (g.ResizeObserver) new ResizeObserver(draw).observe(el);
    const api = { setCenter(la, ln, zz) { c = [la, ln]; if (zz) z = zz; draw(); }, setPoints(a) { pts = a; draw(); },
      fit(a) { if (!a.length) return; const w = (el.clientWidth || 300) * .75, h = (el.clientHeight || 220) * .75;
        for (let zz = 17; zz >= 3; zz--) { const q = a.map(p => px(p.lat, p.lng, zz)), xs = q.map(v => v[0]), ys = q.map(v => v[1]); if (Math.max(...xs) - Math.min(...xs) <= w && Math.max(...ys) - Math.min(...ys) <= h || zz === 3) { z = zz; c = ll((Math.max(...xs) + Math.min(...xs)) / 2, (Math.max(...ys) + Math.min(...ys)) / 2, zz); break; } } draw(); }, draw };
    draw(); return api;
  }
  function locate() {
    return new Promise((res, rej) => {
      if (!navigator.geolocation) return rej(new Error('هذا الجهاز لا يدعم تحديد الموقع'));
      const to = setTimeout(() => rej(new Error('انتهت مهلة تحديد الموقع. حدّد الموقع على الخريطة')), 15000); // a permission prompt left unanswered never times out by itself
      navigator.geolocation.getCurrentPosition(p => { clearTimeout(to); res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }); },
        e => { clearTimeout(to); rej(new Error(e.code === 1 ? 'لم تسمح بالوصول إلى الموقع. حدّد الموقع على الخريطة' : e.code === 3 ? 'انتهت مهلة تحديد الموقع. حدّد الموقع على الخريطة' : 'تعذر تحديد موقعك. حدّد الموقع على الخريطة')); },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 });
    });
  }
  // Pickup / dropoff picker: GPS button + tap on the map to place or correct each pin. get() returns only the points that were set.
  function picker(box, o) {
    o = o || {};
    box.innerHTML = '<div class="row" style="margin-bottom:6px"><button type="button" class="btn" data-g>📍 موقعي الحالي</button>' + (o.single ? '' : '<button type="button" class="btn p" data-t="pickup">تحديد الاستلام</button><button type="button" class="btn" data-t="dropoff">تحديد التسليم</button>') + '</div><div data-m style="height:240px"></div><p class="note" data-s style="margin:4px 0 10px">اضغط على الخريطة لتحديد النقطة أو تعديلها</p>';
    let T = 'pickup', P = { pickup: o.pickup ? { lat: o.pickup[0], lng: o.pickup[1] } : null, dropoff: null };
    const st = t => box.querySelector('[data-s]').textContent = t, render = () => m.setPoints([P.pickup && { ...P.pickup, icon: '📍', label: 'الاستلام' }, P.dropoff && { ...P.dropoff, icon: '🏁', label: 'التسليم' }].filter(Boolean));
    const m = make(box.querySelector('[data-m]'), { center: o.pickup || DEF, zoom: o.pickup ? 16 : 12, onPick: (la, ln) => { P[T] = { lat: la, lng: ln }; render(); st(T === 'pickup' ? 'تم تحديد نقطة الاستلام' : 'تم تحديد نقطة التسليم'); } });
    box.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { T = b.dataset.t; box.querySelectorAll('[data-t]').forEach(x => x.classList.toggle('p', x === b)); });
    const gps = () => { st('جارٍ تحديد موقعك...'); return locate().then(p => { T = 'pickup'; P.pickup = { lat: p.lat, lng: p.lng }; m.setCenter(p.lat, p.lng, 16); render();
      st(p.acc > 100 ? `دقة الموقع تقريبية (±${Math.round(p.acc)} م). عدّل الدبوس بالضغط على الخريطة` : 'تم تحديد موقعك الحالي. يمكنك تعديل الدبوس بالضغط على الخريطة'); }).catch(e => st(e.message)); };
    box.querySelector('[data-g]').onclick = gps; render(); if (o.auto !== false && !o.pickup) gps();
    return { gps, map: m, get() { const r = {}; if (P.pickup) { r.pickup_lat = P.pickup.lat; r.pickup_lng = P.pickup.lng; } if (P.dropoff) { r.dropoff_lat = P.dropoff.lat; r.dropoff_lng = P.dropoff.lng; } return r; } };
  }
  function view(box, pts) { const m = make(box, {}); m.setPoints(pts); m.fit(pts); return m; }
  g.TBMap = { make, picker, view, locate };
})(window);
